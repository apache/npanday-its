using System;
using System.IO;
using Sample;

namespace Sample
{
    public class NPandayIT13018
    {
        public NPandayIT13018()
        {
            Console.WriteLine("Hello");
            string dummy = Sample.MyApp.GetHello();
        }
    }
}
